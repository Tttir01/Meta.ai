# MT5 AI Trader — دستیار معامله‌گر هوشمند متاتریدر 5

ایجنتی که از متاتریدر 5 داده چندتایم‌فریمی می‌گیرد، تحلیل تکنیکال (EMA/RSI/MACD/ADX/ATR، ساختار سوینگ) + فاندامنتال (تقویم اقتصادی، تیترهای خبری) انجام می‌دهد، با مغز Claude تصمیم BUY/SELL/HOLD می‌گیرد، سپس مدیریت ریسک، ثبت سفارش، بریک‌ایون و تریلینگ را انجام می‌دهد.

## نصب (ویندوز — پکیج MetaTrader5 فقط روی ویندوز کار می‌کند)
```bash
git clone <repo> && cd mt5-ai-trader
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env   # اطلاعات حساب دمو و کلید Anthropic
python main.py
```
در MT5: Tools → Options → Expert Advisors → **Allow algorithmic trading**.

## استراتژی‌ها (در `config.yaml` → `strategy`)
| مقدار | توضیح |
|---|---|
| `ai_swing` | تحلیل D1/H4/H1/M15 + تصمیم Claude (پیش‌فرض) |
| `scalp_m1` | اسکالپ M15→M5→M1؛ پولبک و بازگشت به EMA20 در جهت روند، حد ضرر کوچک، سقف معامله روزانه، بدون LLM به‌صورت پیش‌فرض |
| `grid` | گرید رنج: فقط وقتی ADX پایین است، سفارش‌های Limit دوطرفه با SL فاجعه، حجم بر اساس ریسک سبد، بستن کل سبد روی حد ضرر/سود سبد |

هر استراتژی پروفایل جدا دارد (`profiles:`) و مقادیر پایه را override می‌کند.

## ایمنی (مهم)
- پیش‌فرض `mode: dry_run` است: فقط تحلیل و ثبت در `journal.csv`.
- برای معامله واقعی `mode: live`؛ روی حساب **ریل** فقط با `allow_live_account: true`.
- ریسک هر معامله (۰٫۵٪)، سقف ضرر روزانه، سقف پوزیشن، فیلتر اسپرد/سشن/خبر، حداقل RR و اطمینان.
- ابتدا حداقل چند هفته روی دمو تست کنید. هیچ سیستمی سود تضمین نمی‌کند؛ مسئولیت ضرر با شماست.

## ساختار
`config.yaml` تنظیمات · `agent/technical.py` تکنیکال · `agent/fundamental.py` فاندامنتال · `agent/brain.py` تصمیم LLM · `agent/risk.py` ریسک · `agent/mt5_client.py` اتصال MT5 · `main.py` حلقه اصلی
