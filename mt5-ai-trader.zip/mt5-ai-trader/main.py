import csv, logging, os, time, datetime as dt
import yaml
from dotenv import load_dotenv
import MetaTrader5 as mt5
from agent import mt5_client as M, technical, fundamental, brain, risk, grid

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("main")
load_dotenv()

def deep_merge(a, b):
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict): deep_merge(a[k], v)
        else: a[k] = v

cfg = yaml.safe_load(open("config.yaml", encoding="utf-8"))
STRAT = cfg.get("strategy", "ai_swing")
if STRAT not in ("ai_swing", "scalp_m1", "grid"):
    raise SystemExit(f"Unknown strategy: {STRAT}")
deep_merge(cfg, cfg.get("profiles", {}).get(STRAT, {}))
cfg["strategy"] = STRAT
last_bar = {}

def journal(row):
    new = not os.path.exists("journal.csv")
    with open("journal.csv", "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new: w.writerow(["time", "strategy", "symbol", "action", "conf", "volume", "sl", "tp", "executed", "reason"])
        w.writerow([row[0], STRAT] + row[1:])

def manage_open(symbol):
    """Breakeven + ATR trailing for this agent's positions."""
    r = cfg["risk"]
    df = M.rates(symbol, cfg["timeframes"]["entry"])
    if df is None: return
    a = technical.snapshot(df)["atr"]
    for p in M.positions(cfg["magic"], symbol):
        tick = mt5.symbol_info_tick(symbol)
        buy = p.type == mt5.POSITION_TYPE_BUY
        price = tick.bid if buy else tick.ask
        init_risk = abs(p.price_open - p.sl) if p.sl else None
        if not init_risk: continue
        prog = (price - p.price_open) / init_risk if buy else (p.price_open - price) / init_risk
        new_sl = None
        if prog >= r["trail_after_r"]:
            cand = price - a * r["trail_atr_mult"] if buy else price + a * r["trail_atr_mult"]
            if (buy and cand > p.sl) or (not buy and cand < p.sl): new_sl = cand
        elif prog >= r["breakeven_at_r"]:
            if (buy and p.sl < p.price_open) or (not buy and p.sl > p.price_open): new_sl = p.price_open
        if new_sl and cfg["mode"] == "live":
            M.modify_sl(p, round(new_sl, mt5.symbol_info(symbol).digits))
            log.info("%s SL moved to %s (%.2fR)", symbol, new_sl, prog)

def process(symbol):
    tf = cfg["timeframes"]
    entry_df = M.rates(symbol, tf["entry"])
    if entry_df is None: log.warning("%s: not enough data", symbol); return
    bar = entry_df.time.iloc[-1]
    if last_bar.get(symbol) == bar: return   # act once per new entry bar
    last_bar[symbol] = bar
    data = {k: (entry_df if k == "entry" else M.rates(symbol, v)) for k, v in tf.items()}
    if any(d is None for d in data.values()): log.warning("%s: not enough data", symbol); return

    black, why = fundamental.in_blackout(symbol, cfg)
    if black: log.info("%s blackout: %s", symbol, why); return

    snaps = {k: technical.snapshot(d) for k, d in data.items()}
    spread = M.spread_price(symbol)
    exposure = [{"symbol": p.symbol, "type": p.type, "profit": p.profit} for p in M.positions(cfg["magic"])]
    news = fundamental.headlines(cfg) if cfg["llm"]["enabled"] else []
    d = brain.decide(symbol, snaps, spread, news, exposure, cfg)

    r = cfg["risk"]
    ok, msg = risk.validate(symbol, d, snaps["entry"]["atr"], spread,
                            len(M.positions(cfg["magic"])), len(M.positions(cfg["magic"], symbol)), cfg)
    log.info("%s -> %s (%.2f) %s | %s", symbol, d["action"], d.get("confidence", 0), d.get("reason", ""), msg)
    if not ok:
        journal([dt.datetime.now().isoformat(), symbol, d["action"], d.get("confidence"), "", "", "", False, msg]); return

    atr_v = snaps["entry"]["atr"]
    sl_dist = atr_v * (d.get("sl_atr_mult") or r["sl_atr_mult"])
    rr = d.get("tp_rr") or r["tp_rr"]
    tick = mt5.symbol_info_tick(symbol)
    digits = mt5.symbol_info(symbol).digits
    buy = d["action"] == "BUY"
    entry = tick.ask if buy else tick.bid
    sl = round(entry - sl_dist if buy else entry + sl_dist, digits)
    tp = round(entry + sl_dist * rr if buy else entry - sl_dist * rr, digits)
    money = mt5.account_info().equity * r["risk_per_trade_pct"] / 100
    vol = M.calc_volume(symbol, sl_dist, money)

    executed = False
    if cfg["mode"] == "live" and vol > 0:
        executed, _ = M.market_order(symbol, d["action"], vol, sl, tp, cfg["magic"])
        if executed: risk.count_trade()
    else:
        log.info("[DRY-RUN] %s %s vol=%s sl=%s tp=%s", d["action"], symbol, vol, sl, tp)
    journal([dt.datetime.now().isoformat(), symbol, d["action"], d.get("confidence"), vol, sl, tp, executed, d.get("reason", "")])

def main():
    acc = M.connect()
    log.info("Connected: %s | balance %.2f | strategy=%s | mode=%s", acc.login, acc.balance, STRAT, cfg["mode"])
    if cfg["mode"] == "live" and not M.is_demo() and not cfg["allow_live_account"]:
        raise SystemExit("REAL account detected. Set allow_live_account: true to proceed (at your own risk).")
    while True:
        try:
            if risk.daily_loss_hit(cfg): log.warning("Daily loss limit reached - no new trades today.")
            for s in cfg["symbols"]:
                if STRAT == "grid":
                    grid.run(s, cfg)
                else:
                    manage_open(s)
                    if not risk.daily_loss_hit(cfg) and risk.in_session(cfg): process(s)
        except KeyboardInterrupt:
            break
        except Exception:
            log.exception("loop error")
        time.sleep(cfg["loop_seconds"])
    mt5.shutdown()

if __name__ == "__main__":
    main()
