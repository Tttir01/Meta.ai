"""Range-grid strategy with hard safety rails.
Buy-limits below / sell-limits above the mid price, each with TP one step back toward the mid and a
catastrophe SL one step beyond the outermost level. Volume is sized so the worst-case loss of one side
equals basket_risk_pct. Grid only starts in ranging markets (low ADX) and outside news blackouts."""
import logging
import MetaTrader5 as mt5
from . import mt5_client as M, technical, fundamental, risk

log = logging.getLogger("grid")
_last_plan = {}

def _cancel_pending(symbol, cfg):
    for o in M.orders(cfg["magic"], symbol): M.cancel_order(o)

def _flatten(symbol, cfg, why):
    _cancel_pending(symbol, cfg)
    for p in M.positions(cfg["magic"], symbol): M.close_position(p)
    log.warning("%s grid flattened: %s", symbol, why)

def run(symbol, cfg):
    g, live = cfg["grid"], cfg["mode"] == "live"
    pos, ords = M.positions(cfg["magic"], symbol), M.orders(cfg["magic"], symbol)
    eq = mt5.account_info().equity
    df = M.rates(symbol, g["atr_tf"])
    if df is None: return
    snap = technical.snapshot(df)
    tick = mt5.symbol_info_tick(symbol)
    mid = (tick.bid + tick.ask) / 2

    if pos or ords:                                   # ---- manage running grid
        pnl = sum(p.profit + p.swap for p in pos)
        if risk.daily_loss_hit(cfg):
            if live: _flatten(symbol, cfg, "daily loss limit")
            return
        if pnl <= -eq * g["max_basket_loss_pct"] / 100:
            if live: _flatten(symbol, cfg, f"basket stop ({pnl:.2f})")
            return
        if pnl >= eq * g["basket_tp_pct"] / 100:
            if live: _flatten(symbol, cfg, f"basket TP ({pnl:.2f})")
            return
        black, why = fundamental.in_blackout(symbol, cfg)
        if ords and live and (black or snap["adx"] > g["adx_max"] + 5):
            _cancel_pending(symbol, cfg); log.info("%s pending cancelled (news/trend)", symbol); return
        if ords and not pos and live:                 # stale grid -> re-center
            prices = [o.price_open for o in ords]
            center, half = (max(prices) + min(prices)) / 2, (max(prices) - min(prices)) / 2
            if abs(mid - center) > half * 0.5:
                _cancel_pending(symbol, cfg); log.info("%s grid re-centering", symbol)
        return

    # ---- build a new grid
    if risk.daily_loss_hit(cfg) or not risk.in_session(cfg): return
    black, why = fundamental.in_blackout(symbol, cfg)
    if black or snap["adx"] > g["adx_max"]: return
    bar = df.time.iloc[-1]
    if not live and _last_plan.get(symbol) == bar: return
    si = mt5.symbol_info(symbol)
    step, L, digits = snap["atr"] * g["step_atr_mult"], g["levels"], si.digits
    if step < si.trade_stops_level * si.point * 1.5 or M.spread_price(symbol) > step * 0.2:
        log.info("%s grid skipped: step too small vs stops-level/spread", symbol); return
    risk_money = eq * g["basket_risk_pct"] / 100
    worst_dist = step * L * (L + 1) / 2
    vol = M.calc_volume(symbol, worst_dist, risk_money)
    worst = worst_dist / si.trade_tick_size * si.trade_tick_value * vol
    if vol <= 0 or worst > risk_money * 1.5:
        log.info("%s grid skipped: min lot exceeds risk budget", symbol); return
    _last_plan[symbol] = bar
    for i in range(1, L + 1):
        for side, sgn in (("BUY", -1), ("SELL", 1)):
            price = round(mid + sgn * i * step, digits)
            tp = round(mid + sgn * (i - 1) * step, digits)
            sl = round(mid + sgn * (L + 1) * step, digits)
            if live: M.pending_order(symbol, side, price, vol, sl, tp, cfg["magic"])
            else: log.info("[DRY-RUN] grid %s %s @%s tp=%s sl=%s vol=%s", side, symbol, price, tp, sl, vol)
