import json, re, logging, datetime as dt
import xml.etree.ElementTree as ET
import requests

log = logging.getLogger("fundamental")
import time as _t
_cache = {}
def _cached(key, ttl, fn):
    hit = _cache.get(key)
    if hit and _t.time() - hit[0] < ttl: return hit[1]
    val = fn(); _cache[key] = (_t.time(), val); return val

def _load_calendar(src):
    if not src: return []
    return _cached(('cal', src), 300, lambda: _load_calendar_raw(src))

def _load_calendar_raw(src):
    try:
        if src.startswith("http"):
            return requests.get(src, timeout=10).json()
        with open(src, encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log.warning("calendar load failed: %s", e)
        return []

def currencies_of(symbol):
    s = symbol.upper()
    if s.startswith("XAU") or s.startswith("XAG"): return {s[:3], "USD"}
    return {s[:3], s[3:6]}

def in_blackout(symbol, cfg):
    fcfg = cfg["fundamental"]
    now = dt.datetime.now(dt.timezone.utc)
    cur = currencies_of(symbol)
    for ev in _load_calendar(fcfg.get("calendar_url", "")):
        try:
            if ev.get("impact", "").lower() != "high" or ev["currency"].upper() not in cur: continue
            t = dt.datetime.fromisoformat(ev["time"])
            if abs((t - now).total_seconds()) <= fcfg["blackout_minutes"] * 60:
                return True, ev.get("title", "high-impact event")
        except Exception:
            continue
    return False, ""

def headlines(cfg):
    return _cached('rss', 600, lambda: _headlines_raw(cfg))

def _headlines_raw(cfg):
    out = []
    for url in cfg["fundamental"].get("rss_feeds", []):
        try:
            root = ET.fromstring(requests.get(url, timeout=10).content)
            for it in root.iter("item"):
                t = re.sub(r"\s+", " ", (it.findtext("title") or "")).strip()
                if t: out.append(t)
        except Exception as e:
            log.warning("rss failed %s: %s", url, e)
    return out[: cfg["fundamental"]["max_headlines"]]
