import os, logging
import pandas as pd
import MetaTrader5 as mt5

log = logging.getLogger("mt5")
TF = {"M1": mt5.TIMEFRAME_M1, "M5": mt5.TIMEFRAME_M5, "M15": mt5.TIMEFRAME_M15,
      "M30": mt5.TIMEFRAME_M30, "H1": mt5.TIMEFRAME_H1, "H4": mt5.TIMEFRAME_H4, "D1": mt5.TIMEFRAME_D1}

def connect():
    kw = {}
    if os.getenv("MT5_LOGIN"):
        kw = dict(login=int(os.getenv("MT5_LOGIN")), password=os.getenv("MT5_PASSWORD"),
                  server=os.getenv("MT5_SERVER"))
    if not mt5.initialize(**kw):
        raise RuntimeError(f"MT5 init failed: {mt5.last_error()}")
    return mt5.account_info()

def is_demo():
    return mt5.account_info().trade_mode == mt5.ACCOUNT_TRADE_MODE_DEMO

def rates(symbol, tf, n=400):
    mt5.symbol_select(symbol, True)
    r = mt5.copy_rates_from_pos(symbol, TF[tf], 0, n)
    if r is None or len(r) < 250: return None
    df = pd.DataFrame(r)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    return df.rename(columns={"tick_volume": "volume"})

def spread_price(symbol):
    t = mt5.symbol_info_tick(symbol)
    return t.ask - t.bid

def positions(magic, symbol=None):
    p = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
    return [x for x in (p or []) if x.magic == magic]

def calc_volume(symbol, sl_distance, risk_money):
    si = mt5.symbol_info(symbol)
    loss_per_lot = sl_distance / si.trade_tick_size * si.trade_tick_value
    if loss_per_lot <= 0: return 0.0
    vol = risk_money / loss_per_lot
    step = si.volume_step
    vol = max(si.volume_min, min(si.volume_max, int(vol / step) * step))
    return round(vol, 2)

def _fill_mode(symbol):
    m = mt5.symbol_info(symbol).filling_mode
    if m & 1: return mt5.ORDER_FILLING_FOK
    if m & 2: return mt5.ORDER_FILLING_IOC
    return mt5.ORDER_FILLING_RETURN

def market_order(symbol, side, volume, sl, tp, magic, comment="ai-agent"):
    t = mt5.symbol_info_tick(symbol)
    buy = side == "BUY"
    req = {"action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": volume,
           "type": mt5.ORDER_TYPE_BUY if buy else mt5.ORDER_TYPE_SELL,
           "price": t.ask if buy else t.bid, "sl": sl, "tp": tp, "deviation": 20,
           "magic": magic, "comment": comment, "type_time": mt5.ORDER_TIME_GTC,
           "type_filling": _fill_mode(symbol)}
    res = mt5.order_send(req)
    ok = res is not None and res.retcode == mt5.TRADE_RETCODE_DONE
    if not ok: log.error("order failed: %s", res)
    return ok, res

def modify_sl(pos, new_sl):
    req = {"action": mt5.TRADE_ACTION_SLTP, "position": pos.ticket, "symbol": pos.symbol,
           "sl": new_sl, "tp": pos.tp}
    res = mt5.order_send(req)
    return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE

def orders(magic, symbol=None):
    o = mt5.orders_get(symbol=symbol) if symbol else mt5.orders_get()
    return [x for x in (o or []) if x.magic == magic]

def pending_order(symbol, side, price, volume, sl, tp, magic, comment="ai-grid"):
    req = {"action": mt5.TRADE_ACTION_PENDING, "symbol": symbol, "volume": volume,
           "type": mt5.ORDER_TYPE_BUY_LIMIT if side == "BUY" else mt5.ORDER_TYPE_SELL_LIMIT,
           "price": price, "sl": sl, "tp": tp, "magic": magic, "comment": comment,
           "type_time": mt5.ORDER_TIME_GTC, "type_filling": mt5.ORDER_FILLING_RETURN}
    res = mt5.order_send(req)
    ok = res is not None and res.retcode == mt5.TRADE_RETCODE_DONE
    if not ok: log.error("pending failed: %s", res)
    return ok

def cancel_order(o):
    res = mt5.order_send({"action": mt5.TRADE_ACTION_REMOVE, "order": o.ticket})
    return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE

def close_position(p):
    t = mt5.symbol_info_tick(p.symbol)
    buy = p.type == mt5.POSITION_TYPE_BUY
    res = mt5.order_send({"action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol, "position": p.ticket,
                          "volume": p.volume, "type": mt5.ORDER_TYPE_SELL if buy else mt5.ORDER_TYPE_BUY,
                          "price": t.bid if buy else t.ask, "deviation": 20, "magic": p.magic,
                          "comment": "ai-close", "type_time": mt5.ORDER_TIME_GTC,
                          "type_filling": _fill_mode(p.symbol)})
    return res is not None and res.retcode == mt5.TRADE_RETCODE_DONE
