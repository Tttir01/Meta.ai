import json, os, logging
from .technical import rule_bias

log = logging.getLogger("brain")

SYSTEM = """You are a disciplined professional discretionary trader (price action, multi-timeframe
structure, macro awareness). You receive multi-timeframe indicator snapshots, spread, open exposure and
recent headlines for ONE symbol. Decide: BUY, SELL or HOLD for the next entry on the entry timeframe.
Rules: trade only with higher-timeframe alignment, avoid chasing extended RSI, prefer HOLD when unclear,
never trade into stated high-impact events. Capital preservation first.
If strategy is "scalp_m1": entry TF is M1, look for pullback-and-reclaim in the direction of M15/M5 trend,
tight stops, prefer HOLD in low volatility.
Reply with ONLY JSON: {"action":"BUY|SELL|HOLD","confidence":0..1,"sl_atr_mult":number|null,
"tp_rr":number|null,"reason":"<=40 words"}"""

def decide(symbol, snaps, spread, news, exposure, cfg):
    if not cfg["llm"]["enabled"] or not os.getenv("ANTHROPIC_API_KEY"):
        return rule_bias(snaps, cfg.get("strategy", "ai_swing"))
    try:
        import anthropic
        client = anthropic.Anthropic()
        payload = {"strategy": cfg.get("strategy"), "symbol": symbol, "spread": spread, "snapshots": snaps,
                   "headlines": news, "open_positions": exposure}
        r = client.messages.create(model=cfg["llm"]["model"], max_tokens=400, system=SYSTEM,
                                   messages=[{"role": "user", "content": json.dumps(payload)}])
        txt = "".join(b.text for b in r.content if b.type == "text")
        txt = txt[txt.find("{"): txt.rfind("}") + 1]
        d = json.loads(txt)
        d["action"] = str(d.get("action", "HOLD")).upper()
        return d
    except Exception as e:
        log.warning("LLM failed (%s) -> rule fallback", e)
        return rule_bias(snaps, cfg.get("strategy", "ai_swing"))
