from .indicators import ema, rsi, atr, macd_hist, adx

def snapshot(df, lookback=20):
    """Compact technical read of one timeframe (uses closed bars only)."""
    df = df.iloc[:-1].copy()  # drop forming bar
    c = df.close
    e20, e50, e200 = ema(c, 20), ema(c, 50), ema(c, 200)
    a = atr(df)
    last = c.iloc[-1]
    trend = "up" if e50.iloc[-1] > e200.iloc[-1] and last > e50.iloc[-1] else \
            "down" if e50.iloc[-1] < e200.iloc[-1] and last < e50.iloc[-1] else "range"
    return {
        "close": round(float(last), 5),
        "trend": trend,
        "ema20": round(float(e20.iloc[-1]), 5),
        "ema50": round(float(e50.iloc[-1]), 5),
        "ema200": round(float(e200.iloc[-1]), 5),
        "rsi": round(float(rsi(c).iloc[-1]), 1),
        "macd_hist": round(float(macd_hist(c).iloc[-1]), 6),
        "adx": round(float(adx(df).iloc[-1]), 1),
        "atr": round(float(a.iloc[-1]), 5),
        "prev_close": round(float(c.iloc[-2]), 5),
        "prev_ema20": round(float(e20.iloc[-2]), 5),
        "swing_high": round(float(df.high.tail(lookback).max()), 5),
        "swing_low": round(float(df.low.tail(lookback).min()), 5),
    }

def scalp_rule(snaps):
    """M1 scalp: trade pullback-and-reclaim of EMA20 in the direction of M15+M5 trend."""
    h, s, e = snaps["bias"], snaps["setup"], snaps["entry"]
    up = h["trend"] == "up" and s["trend"] == "up"
    dn = h["trend"] == "down" and s["trend"] == "down"
    reclaim_up = e["prev_close"] < e["prev_ema20"] and e["close"] > e["ema20"]
    reclaim_dn = e["prev_close"] > e["prev_ema20"] and e["close"] < e["ema20"]
    if up and reclaim_up and 40 <= e["rsi"] <= 68 and s["adx"] > 18:
        return {"action": "BUY", "confidence": 0.7, "reason": "M15/M5 up + M1 EMA20 reclaim (scalp rules)"}
    if dn and reclaim_dn and 32 <= e["rsi"] <= 60 and s["adx"] > 18:
        return {"action": "SELL", "confidence": 0.7, "reason": "M15/M5 down + M1 EMA20 reject (scalp rules)"}
    return {"action": "HOLD", "confidence": 0.0, "reason": "no scalp trigger"}

def rule_bias(snaps, strategy="ai_swing"):
    """Fallback rule-based decision when the LLM is disabled."""
    if strategy == "scalp_m1":
        return scalp_rule(snaps)
    t = [snaps[k]["trend"] for k in ("trend", "bias", "setup")]
    m = snaps["entry"]
    if t.count("up") >= 2 and m["rsi"] < 68 and m["macd_hist"] > 0 and snaps["setup"]["adx"] > 20:
        return {"action": "BUY", "confidence": 0.7, "reason": "MTF uptrend + momentum (rules)"}
    if t.count("down") >= 2 and m["rsi"] > 32 and m["macd_hist"] < 0 and snaps["setup"]["adx"] > 20:
        return {"action": "SELL", "confidence": 0.7, "reason": "MTF downtrend + momentum (rules)"}
    return {"action": "HOLD", "confidence": 0.0, "reason": "no aligned setup"}
