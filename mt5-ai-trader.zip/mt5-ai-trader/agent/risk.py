import json, os, datetime as dt
import MetaTrader5 as mt5

STATE = "state.json"

def _state():
    today = dt.date.today().isoformat()
    s = json.load(open(STATE)) if os.path.exists(STATE) else {}
    if s.get("day") != today:
        s = {"day": today, "start_equity": mt5.account_info().equity}
        json.dump(s, open(STATE, "w"))
    return s

def daily_loss_hit(cfg):
    s = _state()
    eq = mt5.account_info().equity
    return (s["start_equity"] - eq) / s["start_equity"] * 100 >= cfg["risk"]["max_daily_loss_pct"]

def trades_today():
    return _state().get("trades", 0)

def count_trade():
    s = _state(); s["trades"] = s.get("trades", 0) + 1
    json.dump(s, open(STATE, "w"))

def in_session(cfg):
    h = dt.datetime.now().hour
    return cfg["session"]["start_hour"] <= h < cfg["session"]["end_hour"] and dt.datetime.now().weekday() < 5

def validate(symbol, decision, atr_entry, spread, n_open, n_symbol, cfg):
    r = cfg["risk"]
    if decision["action"] not in ("BUY", "SELL"): return False, "HOLD"
    if decision.get("confidence", 0) < r["min_confidence"]: return False, "low confidence"
    if r.get("max_trades_per_day") and trades_today() >= r["max_trades_per_day"]: return False, "daily trade cap"
    if n_open >= r["max_open_positions"]: return False, "max positions"
    if n_symbol >= r["max_positions_per_symbol"]: return False, "symbol already open"
    if spread > atr_entry * r["max_spread_atr_ratio"]: return False, "spread too wide"
    rr = decision.get("tp_rr") or r["tp_rr"]
    if rr < r["min_rr"]: return False, "RR below minimum"
    return True, "ok"
